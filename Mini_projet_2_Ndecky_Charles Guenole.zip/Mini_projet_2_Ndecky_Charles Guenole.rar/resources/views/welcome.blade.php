@extends('layouts.app')

@section('title', 'Accueil - Gestion Garage')

@section('content')
<div class="text-center py-5">
    <div class="container">
        <h1 class="display-4 mb-4">
            <i class="bi bi-car-front text-primary"></i> Gestion Garage
        </h1>
        <p class="lead mb-5">
            Application complète de gestion de garage avec Laravel<br>
            Interface web + API REST
        </p>
        
        <div class="row justify-content-center mb-5">
            <div class="col-md-4 mb-3">
                <div class="card border-primary">
                    <div class="card-body">
                        <h2 class="text-primary">{{ $stats['vehicules'] ?? 0 }}</h2>
                        <h5><i class="bi bi-truck"></i> Véhicules</h5>
                        <a href="{{ route('vehicules-web.index') }}" class="btn btn-outline-primary btn-sm">
                            Gérer
                        </a>
                        <a href="/api/vehicules" target="_blank" class="btn btn-outline-secondary btn-sm">
                            API
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card border-info">
                    <div class="card-body">
                        <h2 class="text-info">{{ $stats['techniciens'] ?? 0 }}</h2>
                        <h5><i class="bi bi-person-badge"></i> Techniciens</h5>
                        <a href="{{ route('techniciens-web.index') }}" class="btn btn-outline-info btn-sm">
                            Gérer
                        </a>
                        <a href="/api/techniciens" target="_blank" class="btn btn-outline-secondary btn-sm">
                            API
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card border-success">
                    <div class="card-body">
                        <h2 class="text-success">{{ $stats['reparations'] ?? 0 }}</h2>
                        <h5><i class="bi bi-tools"></i> Réparations</h5>
                        <a href="{{ route('reparations-web.index') }}" class="btn btn-outline-success btn-sm">
                            Gérer
                        </a>
                        <a href="/api/reparations" target="_blank" class="btn btn-outline-secondary btn-sm">
                            API
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Le reste de votre contenu -->
        <!-- ... -->
    </div>
</div>
@endsection