@extends('layouts.app')

@section('title', 'Modifier Technicien')

@section('content')
    <h1>Modifier le Technicien</h1>
    
    <form action="{{ route('techniciens-web.update', $technicienWeb) }}" method="POST">
        @csrf
        @method('PUT')
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="nom" class="form-label">Nom *</label>
                <input type="text" class="form-control" id="nom" name="nom" 
                       value="{{ old('nom', $technicienWeb->nom) }}" required>
            </div>
            
            <div class="col-md-6 mb-3">
                <label for="prenom" class="form-label">Prénom *</label>
                <input type="text" class="form-control" id="prenom" name="prenom" 
                       value="{{ old('prenom', $technicienWeb->prenom) }}" required>
            </div>
        </div>
        
        <div class="mb-3">
            <label for="specialite" class="form-label">Spécialité *</label>
            <select class="form-select" id="specialite" name="specialite" required>
                <option value="Mécanique" {{ $technicienWeb->specialite == 'Mécanique' ? 'selected' : '' }}>Mécanique</option>
                <option value="Carrosserie" {{ $technicienWeb->specialite == 'Carrosserie' ? 'selected' : '' }}>Carrosserie</option>
                <option value="Électricité" {{ $technicienWeb->specialite == 'Électricité' ? 'selected' : '' }}>Électricité</option>
                <option value="Diagnostic" {{ $technicienWeb->specialite == 'Diagnostic' ? 'selected' : '' }}>Diagnostic</option>
                <option value="Peinture" {{ $technicienWeb->specialite == 'Peinture' ? 'selected' : '' }}>Peinture</option>
            </select>
        </div>
        
        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">Mettre à jour</button>
            <a href="{{ route('techniciens-web.show', $technicienWeb) }}" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
@endsection