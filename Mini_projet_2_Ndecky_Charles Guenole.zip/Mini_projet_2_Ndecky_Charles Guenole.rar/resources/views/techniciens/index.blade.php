@extends('layouts.app')

@section('title', 'Liste des Techniciens')

@section('content')
<div class="card">
    <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
        <h4 class="mb-0">
            <i class="bi bi-person-badge me-2"></i>Liste des Techniciens
        </h4>
        <a href="{{ route('techniciens-web.create') }}" class="btn btn-light btn-sm">
            <i class="bi bi-person-plus me-1"></i> Nouveau
        </a>
    </div>
    
    <div class="card-body">
        @if($techniciens->isEmpty())
        <div class="text-center py-5">
            <i class="bi bi-people display-1 text-muted"></i>
            <h5 class="mt-3 text-muted">Aucun technicien enregistré</h5>
            <a href="{{ route('techniciens-web.create') }}" class="btn btn-primary">
                <i class="bi bi-person-plus me-1"></i> Ajouter un technicien
            </a>
        </div>
        @else
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th width="80">ID</th>
                        <th>Nom & Prénom</th>
                        <th>Spécialité</th>
                        <th class="mobile-hidden">Date création</th>
                        <th width="180" class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($techniciens as $technicien)
                    <tr>
                        <td>
                            <span class="badge bg-secondary">#{{ $technicien->id }}</span>
                        </td>
                        <td>
                            <strong>{{ $technicien->prenom }} {{ $technicien->nom }}</strong>
                        </td>
                        <td>
                            @php
                                $specialiteColors = [
                                    'Mécanique' => 'danger',
                                    'Carrosserie' => 'warning',
                                    'Électricité' => 'info',
                                    'Diagnostic' => 'success',
                                    'Peinture' => 'primary'
                                ];
                                $color = $specialiteColors[$technicien->specialite] ?? 'secondary';
                            @endphp
                            <span class="badge bg-{{ $color }}">
                                {{ $technicien->specialite }}
                            </span>
                        </td>
                        <td class="mobile-hidden">
                            <small class="text-muted">{{ $technicien->created_at->format('d/m/Y') }}</small>
                        </td>
                        <td class="action-buttons">
                            <div class="btn-group" role="group">
                                <a href="{{ route('techniciens-web.show', $technicien) }}" 
                                   class="btn btn-outline-info btn-sm"
                                   title="Voir détails">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <a href="{{ route('techniciens-web.edit', $technicien) }}" 
                                   class="btn btn-outline-warning btn-sm"
                                   title="Modifier">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="{{ route('techniciens-web.destroy', $technicien) }}" 
                                      method="POST" 
                                      class="d-inline"
                                      onsubmit="return confirm('Supprimer ce technicien ?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" 
                                            class="btn btn-outline-danger btn-sm"
                                            title="Supprimer">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mt-3 pt-3 border-top">
            <div class="mb-2 mb-md-0">
                <span class="text-muted">
                    <i class="bi bi-info-circle me-1"></i>
                    Total : <strong>{{ $techniciens->count() }}</strong> technicien(s)
                </span>
            </div>
            <div>
                <a href="{{ url('/api/techniciens') }}" target="_blank" class="btn btn-outline-secondary btn-sm me-2">
                    <i class="bi bi-code-slash me-1"></i> API
                </a>
                <a href="{{ route('techniciens-web.create') }}" class="btn btn-primary btn-sm">
                    <i class="bi bi-person-plus me-1"></i> Ajouter
                </a>
            </div>
        </div>
        @endif
    </div>
</div>
@endsection