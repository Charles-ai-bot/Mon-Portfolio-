@extends('layouts.app')

@section('title', 'Nouveau Technicien')

@section('content')
    <h1>Nouveau Technicien</h1>
    
    <form action="{{ route('techniciens-web.store') }}" method="POST">
        @csrf
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="nom" class="form-label">Nom *</label>
                <input type="text" class="form-control" id="nom" name="nom" required value="{{ old('nom') }}">
            </div>
            
            <div class="col-md-6 mb-3">
                <label for="prenom" class="form-label">Prénom *</label>
                <input type="text" class="form-control" id="prenom" name="prenom" required value="{{ old('prenom') }}">
            </div>
        </div>
        
        <div class="mb-3">
            <label for="specialite" class="form-label">Spécialité *</label>
            <select class="form-select" id="specialite" name="specialite" required>
                <option value="">Choisir une spécialité</option>
                <option value="Mécanique">Mécanique</option>
                <option value="Carrosserie">Carrosserie</option>
                <option value="Électricité">Électricité</option>
                <option value="Diagnostic">Diagnostic</option>
                <option value="Peinture">Peinture</option>
            </select>
        </div>
        
        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">Créer</button>
            <a href="{{ route('techniciens-web.index') }}" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
@endsection