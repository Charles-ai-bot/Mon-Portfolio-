@extends('layouts.app')

@section('title', 'Détails Technicien')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Détails du Technicien</h1>
    <div class="btn-group">
        <a href="{{ route('techniciens-web.edit', $technicien) }}" class="btn btn-warning">
            <i class="bi bi-pencil"></i> Modifier
        </a>
        <a href="{{ route('techniciens-web.index') }}" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Retour
        </a>
    </div>
</div>

<div class="card">
    <div class="card-header bg-info text-white">
        <h5 class="mb-0">Informations du technicien</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <p><strong>ID:</strong> {{ $technicien->id }}</p>
                <p><strong>Nom:</strong> {{ $technicien->nom }}</p>
                <p><strong>Prénom:</strong> {{ $technicien->prenom }}</p>
                <p><strong>Spécialité:</strong> 
                    <span class="badge bg-primary">{{ $technicien->specialite }}</span>
                </p>
            </div>
            <div class="col-md-6">
                <p><strong>Créé le:</strong> {{ $technicien->created_at->format('d/m/Y H:i') }}</p>
                <p><strong>Modifié le:</strong> {{ $technicien->updated_at->format('d/m/Y H:i') }}</p>
                <p><strong>Nombre de réparations:</strong> 
                    <span class="badge bg-info">{{ $technicien->reparations_count }}</span>
                </p>
            </div>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h5 class="mb-0">Réparations assignées</h5>
    </div>
    <div class="card-body">
        @if($technicien->reparations->isEmpty())
            <div class="alert alert-info">Aucune réparation assignée à ce technicien.</div>
        @else
            <div class="table-responsive">
                <table class="table table-sm table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Date</th>
                            <th>Véhicule</th>
                            <th>Objet</th>
                            <th>Durée</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($technicien->reparations as $reparation)
                            <tr>
                                <td>#{{ $reparation->id }}</td>
                                <td>{{ \Carbon\Carbon::parse($reparation->date)->format('d/m/Y') }}</td>
                                <td>
                                    <strong>{{ $reparation->vehicule->immatriculation }}</strong>
                                    <small class="text-muted d-block">{{ $reparation->vehicule->marque }}</small>
                                </td>
                                <td>{{ Str::limit($reparation->objet_reparation, 30) }}</td>
                                <td>{{ $reparation->duree_main_oeuvre }}h</td>
                                <td>
                                    <a href="{{ route('reparations-web.show', $reparation) }}" 
                                       class="btn btn-sm btn-outline-info">
                                        Voir
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </div>
</div>

<div class="mt-3">
    <form action="{{ route('techniciens-web.destroy', $technicien) }}" method="POST" 
          onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer ce technicien ?');">
        @csrf
        @method('DELETE')
        <button type="submit" class="btn btn-danger">
            <i class="bi bi-trash"></i> Supprimer ce technicien
        </button>
    </form>
</div>
@endsection