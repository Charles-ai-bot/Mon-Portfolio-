@extends('layouts.app')

@section('title', 'Détails Réparation')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Détails de la Réparation</h1>
    <div class="btn-group">
        <a href="{{ route('reparations-web.edit', $reparation) }}" class="btn btn-warning">
            <i class="bi bi-pencil"></i> Modifier
        </a>
        <a href="{{ route('reparations-web.index') }}" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Retour
        </a>
    </div>
</div>

<div class="card">
    <div class="card-header bg-success text-white">
        <h5 class="mb-0">Informations de la réparation</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <p><strong>ID:</strong> #{{ $reparation->id }}</p>
                <p><strong>Véhicule:</strong> 
                    <a href="{{ route('vehicules-web.show', $reparation->vehicule) }}" class="text-decoration-none">
                        <i class="bi bi-car-front"></i>
                        {{ $reparation->vehicule->immatriculation }}
                        ({{ $reparation->vehicule->marque }} {{ $reparation->vehicule->modele }})
                    </a>
                </p>
                <p><strong>Date:</strong> {{ \Carbon\Carbon::parse($reparation->date)->format('d/m/Y H:i') }}</p>
                <p><strong>Durée:</strong> <span class="badge bg-warning text-dark">{{ $reparation->duree_main_oeuvre }} heures</span></p>
            </div>
            <div class="col-md-6">
                <p><strong>Objet:</strong> {{ $reparation->objet_reparation }}</p>
                <p><strong>Créé le:</strong> {{ $reparation->created_at->format('d/m/Y H:i') }}</p>
                <p><strong>Modifié le:</strong> {{ $reparation->updated_at->format('d/m/Y H:i') }}</p>
            </div>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h5 class="mb-0">Techniciens assignés</h5>
    </div>
    <div class="card-body">
        @if($reparation->techniciens->isEmpty())
            <div class="alert alert-info">Aucun technicien assigné.</div>
        @else
            <div class="row">
                @foreach($reparation->techniciens as $technicien)
                    <div class="col-md-4 col-sm-6 mb-3">
                        <div class="card h-100">
                            <div class="card-body text-center">
                                <h6 class="card-title">{{ $technicien->prenom }} {{ $technicien->nom }}</h6>
                                <span class="badge bg-info">{{ $technicien->specialite }}</span>
                                <div class="mt-2">
                                    <a href="{{ route('techniciens-web.show', $technicien) }}" 
                                       class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-person"></i> Voir profil
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif
    </div>
</div>

<div class="mt-3">
    <form action="{{ route('reparations-web.destroy', $reparation) }}" method="POST" 
          onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer cette réparation ?');">
        @csrf
        @method('DELETE')
        <button type="submit" class="btn btn-danger">
            <i class="bi bi-trash"></i> Supprimer cette réparation
        </button>
    </form>
</div>
@endsection