@extends('layouts.app')

@section('title', 'Modifier Réparation')

@section('content')
<div class="card">
    <div class="card-header bg-warning text-dark">
        <h4 class="mb-0">
            <i class="bi bi-pencil-square"></i> Modifier la Réparation #{{ $reparation->id }}
        </h4>
    </div>
    
    <div class="card-body">
        <form action="{{ route('reparations-web.update', $reparation) }}" method="POST">
            @csrf
            @method('PUT')
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="vehicule_id" class="form-label">Véhicule *</label>
                    <select class="form-select @error('vehicule_id') is-invalid @enderror" 
                            id="vehicule_id" name="vehicule_id" required>
                        <option value="">Sélectionner un véhicule</option>
                        @foreach($vehicules as $vehicule)
                            <option value="{{ $vehicule->id }}" 
                                {{ old('vehicule_id', $reparation->vehicule_id) == $vehicule->id ? 'selected' : '' }}>
                                {{ $vehicule->immatriculation }} - {{ $vehicule->marque }} {{ $vehicule->modele }}
                            </option>
                        @endforeach
                    </select>
                    @error('vehicule_id')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="date" class="form-label">Date *</label>
                    <input type="datetime-local" class="form-control @error('date') is-invalid @enderror" 
                           id="date" name="date" 
                           value="{{ old('date', \Carbon\Carbon::parse($reparation->date)->format('Y-m-d\TH:i')) }}" 
                           required>
                    @error('date')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="duree_main_oeuvre" class="form-label">Durée (heures) *</label>
                    <input type="number" class="form-control @error('duree_main_oeuvre') is-invalid @enderror" 
                           id="duree_main_oeuvre" name="duree_main_oeuvre" 
                           min="1" max="24" step="0.5"
                           value="{{ old('duree_main_oeuvre', $reparation->duree_main_oeuvre) }}" 
                           required>
                    @error('duree_main_oeuvre')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="objet_reparation" class="form-label">Objet de la réparation *</label>
                    <input type="text" class="form-control @error('objet_reparation') is-invalid @enderror" 
                           id="objet_reparation" name="objet_reparation" 
                           value="{{ old('objet_reparation', $reparation->objet_reparation) }}" 
                           required placeholder="Ex: Vidange, Freins, Carrosserie...">
                    @error('objet_reparation')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>
            
            <div class="mb-4">
                <label class="form-label fw-bold">Techniciens assignés *</label>
                <div class="border p-3 rounded">
                    <div class="row">
                        @foreach($techniciens as $technicien)
                            <div class="col-md-3 col-sm-4 mb-2">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" 
                                           name="technicien_ids[]" 
                                           value="{{ $technicien->id }}" 
                                           id="tech{{ $technicien->id }}"
                                           {{ in_array($technicien->id, old('technicien_ids', $reparation->techniciens->pluck('id')->toArray())) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="tech{{ $technicien->id }}">
                                        <strong>{{ $technicien->prenom }} {{ $technicien->nom }}</strong>
                                        <small class="text-muted d-block">{{ $technicien->specialite }}</small>
                                    </label>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
            
            <div class="d-flex justify-content-between">
                <div>
                    <a href="{{ route('reparations-web.show', $reparation) }}" class="btn btn-secondary me-2">
                        <i class="bi bi-x-circle"></i> Annuler
                    </a>
                    <button type="submit" class="btn btn-warning">
                        <i class="bi bi-check-circle"></i> Mettre à jour
                    </button>
                </div>
                
                <a href="{{ route('reparations-web.index') }}" class="btn btn-outline-primary">
                    <i class="bi bi-list"></i> Retour à la liste
                </a>
            </div>
        </form>
    </div>
</div>
@endsection