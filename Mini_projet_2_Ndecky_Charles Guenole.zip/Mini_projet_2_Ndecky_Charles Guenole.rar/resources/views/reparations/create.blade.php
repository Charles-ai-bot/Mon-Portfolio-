@extends('layouts.app')

@section('title', 'Nouvelle Réparation')

@section('content')
    <h1>Nouvelle Réparation</h1>
    
    <form action="{{ route('reparations-web.store') }}" method="POST">
        @csrf
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="vehicule_id" class="form-label">Véhicule *</label>
                <select class="form-select" id="vehicule_id" name="vehicule_id" required>
                    <option value="">Sélectionner un véhicule</option>
                    @foreach($vehicules as $vehicule)
                        <option value="{{ $vehicule->id }}" {{ old('vehicule_id') == $vehicule->id ? 'selected' : '' }}>
                            {{ $vehicule->immatriculation }} - {{ $vehicule->marque }} {{ $vehicule->modele }}
                        </option>
                    @endforeach
                </select>
            </div>
            
            <div class="col-md-6 mb-3">
                <label for="date" class="form-label">Date *</label>
                <input type="datetime-local" class="form-control" id="date" name="date" 
                       value="{{ old('date', now()->format('Y-m-d\TH:i')) }}" required>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="duree_main_oeuvre" class="form-label">Durée (heures) *</label>
                <input type="number" class="form-control" id="duree_main_oeuvre" name="duree_main_oeuvre" 
                       min="1" max="24" value="{{ old('duree_main_oeuvre', 1) }}" required>
            </div>
            
            <div class="col-md-6 mb-3">
                <label for="objet_reparation" class="form-label">Objet de la réparation *</label>
                <input type="text" class="form-control" id="objet_reparation" name="objet_reparation" 
                       value="{{ old('objet_reparation') }}" required placeholder="Ex: Vidange, Freins...">
            </div>
        </div>
        
        <div class="mb-3">
            <label class="form-label">Techniciens assignés</label>
            <div class="row">
                @foreach($techniciens as $technicien)
                    <div class="col-md-3 mb-2">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" 
                                   name="technicien_ids[]" 
                                   value="{{ $technicien->id }}" 
                                   id="tech{{ $technicien->id }}">
                            <label class="form-check-label" for="tech{{ $technicien->id }}">
                                {{ $technicien->prenom }} {{ $technicien->nom }}
                                <small class="text-muted d-block">{{ $technicien->specialite }}</small>
                            </label>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
        
        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">Créer la réparation</button>
            <a href="{{ route('reparations-web.index') }}" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
@endsection