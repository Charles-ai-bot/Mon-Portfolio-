@extends('layouts.app')

@section('title', 'Liste des Réparations')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold">Liste des Réparations</h3>
        <a href="{{ route('reparations-web.create') }}" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Nouvelle réparation
        </a>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle-fill"></i> {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if($reparations->isEmpty())
        <div class="text-center py-5">
            <i class="bi bi-tools display-1 text-muted"></i>
            <h4 class="mt-3 text-muted">Aucune réparation enregistrée</h4>
            <p class="text-muted">Commencez par ajouter votre première réparation</p>
            <a href="{{ route('reparations-web.create') }}" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i> Ajouter une réparation
            </a>
        </div>
    @else
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-primary">
                            <tr>
                                <th>ID</th>
                                <th>Véhicule</th>
                                <th class="d-none d-md-table-cell">Date</th>
                                <th>Durée</th>
                                <th>Objet</th>
                                <th class="d-none d-sm-table-cell">Techniciens</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($reparations as $reparation)
                                <tr>
                                    <td>
                                        <span class="badge bg-secondary">#{{ $reparation->id }}</span>
                                    </td>
                                    <td>
                                        <div class="fw-bold">{{ $reparation->vehicule->immatriculation ?? 'N/A' }}</div>
                                        <small class="text-muted">{{ $reparation->vehicule->marque ?? '' }} {{ $reparation->vehicule->modele ?? '' }}</small>
                                    </td>
                                    <td class="d-none d-md-table-cell">
                                        {{ \Carbon\Carbon::parse($reparation->date)->format('d/m/Y') }}
                                    </td>
                                    <td>
                                        <span class="badge bg-warning text-dark">
                                            {{ $reparation->duree_main_oeuvre ?? $reparation->duree }}h
                                        </span>
                                    </td>
                                    <td>
                                        <span title="{{ $reparation->objet_reparation ?? $reparation->objet }}">
                                            {{ Str::limit($reparation->objet_reparation ?? $reparation->objet, 30) }}
                                        </span>
                                    </td>
                                    <td class="d-none d-sm-table-cell">
                                        @forelse($reparation->techniciens as $technicien)
                                            <span class="badge bg-info me-1">
                                                {{ $technicien->prenom }}
                                            </span>
                                        @empty
                                            <span class="badge bg-secondary">Aucun</span>
                                        @endforelse
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="{{ route('reparations-web.show', $reparation) }}" 
                                               class="btn btn-outline-info btn-sm"
                                               title="Voir détails">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <a href="{{ route('reparations-web.edit', $reparation) }}" 
                                               class="btn btn-outline-warning btn-sm"
                                               title="Modifier">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <form action="{{ route('reparations-web.destroy', $reparation) }}" 
                                                  method="POST" 
                                                  class="d-inline"
                                                  onsubmit="return confirm('Supprimer cette réparation ?')">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" 
                                                        class="btn btn-outline-danger btn-sm"
                                                        title="Supprimer">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <!-- PAGINATION (fonctionnera avec paginate()) -->
                @if($reparations->hasPages())
                    <div class="d-flex justify-content-center mt-4">
                        {{ $reparations->links() }}
                    </div>
                @endif

                <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                    <div class="text-muted">
                        <i class="bi bi-info-circle"></i>
                        Total : <strong>{{ $reparations->total() }}</strong> réparation(s)
                    </div>
                    <div>
                        <a href="/api/reparations" target="_blank" class="btn btn-outline-secondary btn-sm">
                            <i class="bi bi-code-slash"></i> Voir API
                        </a>
                    </div>
                </div>
            </div>
        </div>
    @endif
</div>
@endsection