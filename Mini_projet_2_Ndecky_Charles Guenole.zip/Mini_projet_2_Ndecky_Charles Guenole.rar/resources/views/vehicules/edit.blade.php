@extends('layouts.app')

@section('title', 'Modifier Véhicule')

@section('content')
<div class="card">
    <div class="card-header bg-warning text-dark">
        <h4 class="mb-0">
            <i class="bi bi-pencil-square"></i> Modifier le Véhicule #{{ $vehicule->id }}
        </h4>
    </div>
    
    <div class="card-body">
        <form action="{{ route('vehicules-web.update', $vehicule) }}" method="POST">
            @csrf
            @method('PUT')
            
            <div class="mb-3">
                <label for="immatriculation" class="form-label">Immatriculation *</label>
                <input type="text" class="form-control @error('immatriculation') is-invalid @enderror" 
                       id="immatriculation" name="immatriculation" 
                       value="{{ old('immatriculation', $vehicule->immatriculation) }}" 
                       required placeholder="Ex: AB-123-CD">
                @error('immatriculation')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            
            <div class="mb-3">
                <label for="marque" class="form-label">Marque *</label>
                <input type="text" class="form-control @error('marque') is-invalid @enderror" 
                       id="marque" name="marque" 
                       value="{{ old('marque', $vehicule->marque) }}" 
                       required placeholder="Ex: Renault">
                @error('marque')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            
            <div class="mb-3">
                <label for="modele" class="form-label">Modèle *</label>
                <input type="text" class="form-control @error('modele') is-invalid @enderror" 
                       id="modele" name="modele" 
                       value="{{ old('modele', $vehicule->modele) }}" 
                       required placeholder="Ex: Clio">
                @error('modele')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            
            <div class="d-flex justify-content-between">
                <div>
                    <a href="{{ route('vehicules-web.show', $vehicule) }}" class="btn btn-secondary me-2">
                        <i class="bi bi-x-circle"></i> Annuler
                    </a>
                    <button type="submit" class="btn btn-warning">
                        <i class="bi bi-check-circle"></i> Mettre à jour
                    </button>
                </div>
                
                <a href="{{ route('vehicules-web.index') }}" class="btn btn-outline-primary">
                    <i class="bi bi-list"></i> Retour à la liste
                </a>
            </div>
        </form>
    </div>
</div>
@endsection