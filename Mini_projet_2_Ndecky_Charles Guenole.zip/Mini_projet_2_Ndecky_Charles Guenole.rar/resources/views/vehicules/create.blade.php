@extends('layouts.app')

@section('title', 'Nouveau Véhicule')

@section('content')
    <h1>Nouveau Véhicule</h1>
    
    <form action="{{ route('vehicules-web.store') }}" method="POST">
        @csrf
        
        <div class="mb-3">
            <label for="immatriculation" class="form-label">Immatriculation *</label>
            <input type="text" class="form-control" id="immatriculation" name="immatriculation" 
                   required placeholder="Ex: AB-123-CD" value="{{ old('immatriculation') }}">
        </div>
        
        <div class="mb-3">
            <label for="marque" class="form-label">Marque *</label>
            <input type="text" class="form-control" id="marque" name="marque" 
                   required placeholder="Ex: Renault" value="{{ old('marque') }}">
        </div>
        
        <div class="mb-3">
            <label for="modele" class="form-label">Modèle *</label>
            <input type="text" class="form-control" id="modele" name="modele" 
                   required placeholder="Ex: Clio" value="{{ old('modele') }}">
        </div>
        
        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">Créer</button>
            <a href="{{ route('vehicules-web.index') }}" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
@endsection