@extends('layouts.app')

@section('title', 'Détails Véhicule')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Détails du Véhicule</h1>
    <div class="btn-group">
        <a href="{{ route('vehicules-web.edit', $vehicule) }}" class="btn btn-warning">
            <i class="bi bi-pencil"></i> Modifier
        </a>
        <a href="{{ route('vehicules-web.index') }}" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Retour
        </a>
    </div>
</div>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0">Informations du véhicule</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <p><strong>ID:</strong> {{ $vehicule->id }}</p>
                <p><strong>Immatriculation:</strong> <span class="badge bg-dark fs-6">{{ $vehicule->immatriculation }}</span></p>
                <p><strong>Marque:</strong> {{ $vehicule->marque }}</p>
                <p><strong>Modèle:</strong> {{ $vehicule->modele }}</p>
            </div>
            <div class="col-md-6">
                <p><strong>Créé le:</strong> {{ $vehicule->created_at->format('d/m/Y H:i') }}</p>
                <p><strong>Modifié le:</strong> {{ $vehicule->updated_at->format('d/m/Y H:i') }}</p>
                <p><strong>Nombre de réparations:</strong> 
                    <span class="badge bg-info">{{ $vehicule->reparations_count }}</span>
                </p>
            </div>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h5 class="mb-0">Réparations associées</h5>
    </div>
    <div class="card-body">
        @if($vehicule->reparations->isEmpty())
            <div class="alert alert-info">Aucune réparation pour ce véhicule.</div>
        @else
            <div class="table-responsive">
                <table class="table table-sm table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Date</th>
                            <th>Objet</th>
                            <th>Durée</th>
                            <th>Techniciens</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($vehicule->reparations as $reparation)
                            <tr>
                                <td>#{{ $reparation->id }}</td>
                                <td>{{ \Carbon\Carbon::parse($reparation->date)->format('d/m/Y') }}</td>
                                <td>{{ Str::limit($reparation->objet_reparation, 40) }}</td>
                                <td>{{ $reparation->duree_main_oeuvre }}h</td>
                                <td>
                                    @foreach($reparation->techniciens as $tech)
                                        <span class="badge bg-secondary">{{ $tech->prenom }}</span>
                                    @endforeach
                                </td>
                                <td>
                                    <a href="{{ route('reparations-web.show', $reparation) }}" 
                                       class="btn btn-sm btn-outline-info">
                                        Voir
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </div>
</div>

<div class="mt-3">
    <form action="{{ route('vehicules-web.destroy', $vehicule) }}" method="POST" 
          onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer ce véhicule ?');">
        @csrf
        @method('DELETE')
        <button type="submit" class="btn btn-danger">
            <i class="bi bi-trash"></i> Supprimer ce véhicule
        </button>
    </form>
</div>
@endsection