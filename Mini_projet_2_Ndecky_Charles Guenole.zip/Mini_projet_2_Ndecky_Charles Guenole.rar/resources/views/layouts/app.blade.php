<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Garage - @yield('title')</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border: none;
            margin-bottom: 20px;
        }
        .card-header {
            border-radius: 10px 10px 0 0 !important;
            font-weight: 600;
        }
        .btn-group-sm > .btn {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }
        .table th {
            font-weight: 600;
            background-color: #f1f3f4;
            border-bottom: 2px solid #dee2e6;
        }
        .table td {
            vertical-align: middle;
        }
        .badge {
            font-size: 0.8em;
            padding: 0.4em 0.8em;
        }
        .action-buttons {
            white-space: nowrap;
            min-width: 140px;
        }
        .mobile-hidden {
            display: table-cell;
        }
        @media (max-width: 768px) {
            .mobile-hidden {
                display: none;
            }
            .action-buttons {
                min-width: auto;
            }
            .btn-group-sm > .btn {
                padding: 0.2rem 0.4rem;
                margin: 1px;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="bi bi-car-front"></i> Gestion Garage
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('/vehicules-web') }}">
                            <i class="bi bi-truck"></i> Véhicules
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('/techniciens-web') }}">
                            <i class="bi bi-person-badge"></i> Techniciens
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('/reparations-web') }}">
                            <i class="bi bi-tools"></i> Réparations
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('/api/vehicules') }}" target="_blank">
                            <i class="bi bi-code-slash"></i> API JSON
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('/api-viewer') }}">
                            <i class="bi bi-code-square"></i> API Viewer
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <main class="container py-4">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i>
                <div>{{ session('success') }}</div>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
            </div>
        @endif
        
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <div>{{ session('error') }}</div>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
            </div>
        @endif
        
        @yield('content')
    </main>
    
    <footer class="bg-light text-center py-3 mt-5 border-top">
        <div class="container">
            <p class="text-muted mb-0">
                <i class="bi bi-c-circle"></i> Gestion Garage - Laravel {{ date('Y') }}
            </p>
        </div>
    </footer>
    
    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-dismiss alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                const alerts = document.querySelectorAll('.alert');
                alerts.forEach(function(alert) {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                });
            }, 5000);
        });
    </script>
</body>
</html>