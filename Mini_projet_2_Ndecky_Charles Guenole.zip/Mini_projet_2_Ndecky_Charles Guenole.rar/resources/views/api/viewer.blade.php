@extends('layouts.app')

@section('title', 'Visualiseur API')

@section('content')
<div class="card">
    <div class="card-header bg-dark text-white">
        <h4 class="mb-0">
            <i class="bi bi-code-slash"></i> Visualiseur d'API - Gestion Garage
        </h4>
    </div>
    
    <div class="card-body">
        <div class="alert alert-info">
            <i class="bi bi-info-circle"></i> Cette page vous permet de visualiser les données de l'API REST.
            Pour tester les méthodes POST, PUT, DELETE, utilisez Thunder Client ou Postman.
        </div>
        
        <div class="row">
            <div class="col-md-4 mb-3">
                <div class="card h-100">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">
                            <i class="bi bi-truck"></i> Véhicules
                        </h5>
                    </div>
                    <div class="card-body d-flex flex-column">
                        <h6>Endpoints disponibles :</h6>
                        <ul class="list-unstyled">
                            <li class="mb-1">
                                <strong>GET</strong> 
                                <a href="/api/vehicules" target="_blank" class="text-decoration-none">
                                    <code>/api/vehicules</code>
                                </a>
                            </li>
                            <li class="mb-1">
                                <strong>GET</strong> 
                                <a href="/api/vehicules/1" target="_blank" class="text-decoration-none">
                                    <code>/api/vehicules/{id}</code>
                                </a>
                            </li>
                            <li class="mb-1">
                                <strong>POST</strong> <code>/api/vehicules</code>
                            </li>
                            <li class="mb-1">
                                <strong>PUT</strong> <code>/api/vehicules/{id}</code>
                            </li>
                            <li class="mb-1">
                                <strong>DELETE</strong> <code>/api/vehicules/{id}</code>
                            </li>
                        </ul>
                        <button class="btn btn-outline-primary mt-auto" onclick="fetchData('/api/vehicules', 'vehicules-data')">
                            <i class="bi bi-download"></i> Charger les véhicules
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card h-100">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">
                            <i class="bi bi-person-badge"></i> Techniciens
                        </h5>
                    </div>
                    <div class="card-body d-flex flex-column">
                        <h6>Endpoints disponibles :</h6>
                        <ul class="list-unstyled">
                            <li class="mb-1">
                                <strong>GET</strong> 
                                <a href="/api/techniciens" target="_blank" class="text-decoration-none">
                                    <code>/api/techniciens</code>
                                </a>
                            </li>
                            <li class="mb-1">
                                <strong>GET</strong> 
                                <a href="/api/techniciens/1" target="_blank" class="text-decoration-none">
                                    <code>/api/techniciens/{id}</code>
                                </a>
                            </li>
                            <li class="mb-1">
                                <strong>POST</strong> <code>/api/techniciens</code>
                            </li>
                            <li class="mb-1">
                                <strong>PUT</strong> <code>/api/techniciens/{id}</code>
                            </li>
                            <li class="mb-1">
                                <strong>DELETE</strong> <code>/api/techniciens/{id}</code>
                            </li>
                        </ul>
                        <button class="btn btn-outline-info mt-auto" onclick="fetchData('/api/techniciens', 'techniciens-data')">
                            <i class="bi bi-download"></i> Charger les techniciens
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card h-100">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">
                            <i class="bi bi-tools"></i> Réparations
                        </h5>
                    </div>
                    <div class="card-body d-flex flex-column">
                        <h6>Endpoints disponibles :</h6>
                        <ul class="list-unstyled">
                            <li class="mb-1">
                                <strong>GET</strong> 
                                <a href="/api/reparations" target="_blank" class="text-decoration-none">
                                    <code>/api/reparations</code>
                                </a>
                            </li>
                            <li class="mb-1">
                                <strong>GET</strong> 
                                <a href="/api/reparations/1" target="_blank" class="text-decoration-none">
                                    <code>/api/reparations/{id}</code>
                                </a>
                            </li>
                            <li class="mb-1">
                                <strong>POST</strong> <code>/api/reparations</code>
                            </li>
                            <li class="mb-1">
                                <strong>PUT</strong> <code>/api/reparations/{id}</code>
                            </li>
                            <li class="mb-1">
                                <strong>DELETE</strong> <code>/api/reparations/{id}</code>
                            </li>
                        </ul>
                        <button class="btn btn-outline-success mt-auto" onclick="fetchData('/api/reparations', 'reparations-data')">
                            <i class="bi bi-download"></i> Charger les réparations
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Section d'affichage des données -->
        <div class="mt-4">
            <div id="vehicules-data" class="data-section" style="display: none;">
                <div class="card">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Données Véhicules</h5>
                        <button class="btn btn-light btn-sm" onclick="copyToClipboard('vehicules-json')">
                            <i class="bi bi-clipboard"></i> Copier
                        </button>
                    </div>
                    <div class="card-body p-0">
                        <pre class="m-0"><code id="vehicules-json" class="json"></code></pre>
                    </div>
                </div>
            </div>
            
            <div id="techniciens-data" class="data-section" style="display: none;">
                <div class="card mt-3">
                    <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Données Techniciens</h5>
                        <button class="btn btn-light btn-sm" onclick="copyToClipboard('techniciens-json')">
                            <i class="bi bi-clipboard"></i> Copier
                        </button>
                    </div>
                    <div class="card-body p-0">
                        <pre class="m-0"><code id="techniciens-json" class="json"></code></pre>
                    </div>
                </div>
            </div>
            
            <div id="reparations-data" class="data-section" style="display: none;">
                <div class="card mt-3">
                    <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Données Réparations</h5>
                        <button class="btn btn-light btn-sm" onclick="copyToClipboard('reparations-json')">
                            <i class="bi bi-clipboard"></i> Copier
                        </button>
                    </div>
                    <div class="card-body p-0">
                        <pre class="m-0"><code id="reparations-json" class="json"></code></pre>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Guide d'utilisation -->
        <div class="card mt-4">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0">
                    <i class="bi bi-lightbulb"></i> Comment tester l'API
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Avec Thunder Client (VS Code) :</h6>
                        <ol>
                            <li>Installez l'extension Thunder Client dans VS Code</li>
                            <li>Ouvrez Thunder Client (icône dans la barre latérale)</li>
                            <li>Créez une nouvelle requête</li>
                            <li>Testez les différentes méthodes HTTP</li>
                        </ol>
                    </div>
                    <div class="col-md-6">
                        <h6>Avec Postman :</h6>
                        <ol>
                            <li>Téléchargez et installez Postman</li>
                            <li>Créez une nouvelle collection "Gestion Garage"</li>
                            <li>Ajoutez des requêtes pour chaque endpoint</li>
                            <li>Testez avec différents corps JSON</li>
                        </ol>
                    </div>
                </div>
                
                <div class="mt-3">
                    <h6>Exemples de requêtes :</h6>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h6>POST /api/vehicules</h6>
                                    <pre class="bg-light p-2"><code>{
  "immatriculation": "AB-123-CD",
  "marque": "Renault",
  "modele": "Clio"
}</code></pre>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h6>POST /api/techniciens</h6>
                                    <pre class="bg-light p-2"><code>{
  "nom": "Martin",
  "prenom": "Pierre",
  "specialite": "Mécanique"
}</code></pre>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h6>POST /api/reparations</h6>
                                    <pre class="bg-light p-2"><code>{
  "vehicule_id": 1,
  "date": "2024-12-15",
  "duree_main_oeuvre": "3",
  "objet_reparation": "Vidange"
}</code></pre>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.data-section {
    transition: all 0.3s ease;
}

pre {
    max-height: 400px;
    overflow: auto;
    margin: 0;
    border-radius: 0 0 0.375rem 0.375rem;
}

.json {
    padding: 1rem;
    font-family: 'Courier New', monospace;
    font-size: 0.9rem;
}
</style>

<script>
function fetchData(url, containerId) {
    // Masquer toutes les sections de données d'abord
    document.querySelectorAll('.data-section').forEach(section => {
        section.style.display = 'none';
    });
    
    // Afficher un indicateur de chargement
    const jsonElement = document.getElementById(containerId.replace('-data', '-json'));
    jsonElement.textContent = 'Chargement en cours...';
    
    // Afficher la section
    const container = document.getElementById(containerId);
    container.style.display = 'block';
    
    // Faire la requête
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Erreur HTTP: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            // Formater le JSON avec indentation
            jsonElement.textContent = JSON.stringify(data, null, 2);
            
            // Appliquer la coloration syntaxique
            if (typeof hljs !== 'undefined') {
                hljs.highlightElement(jsonElement);
            }
            
            // Défiler vers la section
            container.scrollIntoView({ behavior: 'smooth' });
        })
        .catch(error => {
            console.error('Erreur:', error);
            jsonElement.textContent = `Erreur: ${error.message}`;
            alert('Erreur lors du chargement des données. Vérifiez votre connexion.');
        });
}

function copyToClipboard(elementId) {
    const text = document.getElementById(elementId).textContent;
    navigator.clipboard.writeText(text).then(() => {
        // Afficher une notification temporaire
        const button = event.target.closest('button');
        const originalHtml = button.innerHTML;
        button.innerHTML = '<i class="bi bi-check"></i> Copié !';
        button.classList.remove('btn-light');
        button.classList.add('btn-success');
        
        setTimeout(() => {
            button.innerHTML = originalHtml;
            button.classList.remove('btn-success');
            button.classList.add('btn-light');
        }, 2000);
    }).catch(err => {
        console.error('Erreur lors de la copie:', err);
        alert('Erreur lors de la copie');
    });
}

// Charger automatiquement les véhicules au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    // Optionnel: charger automatiquement les véhicules
    // fetchData('/api/vehicules', 'vehicules-data');
});
</script>

<!-- Highlight.js pour la coloration syntaxique -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/styles/github-dark.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/highlight.min.js"></script>
<script>hljs.highlightAll();</script>
@endsection