<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
public function up()
{
    Schema::create('reparations', function (Blueprint $table) {
        $table->id();
        $table->foreignId('vehicule_id')->constrained()->onDelete('cascade');
        $table->date('date');
        $table->string('duree_main_oeuvre');
        $table->text('objet_reparation');
        $table->timestamps();
    });
    
    // Table pivot pour la relation many-to-many entre réparations et techniciens
    Schema::create('reparation_technicien', function (Blueprint $table) {
        $table->id();
        $table->foreignId('reparation_id')->constrained()->onDelete('cascade');
        $table->foreignId('technicien_id')->constrained()->onDelete('cascade');
        $table->timestamps();
    });
}
};
