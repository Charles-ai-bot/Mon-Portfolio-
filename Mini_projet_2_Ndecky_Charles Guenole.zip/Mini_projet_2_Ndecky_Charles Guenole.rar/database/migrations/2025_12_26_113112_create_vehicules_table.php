<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
public function up()
{
    Schema::create('vehicules', function (Blueprint $table) {
        $table->id();
        $table->string('immatriculation');
        $table->string('marque');
        $table->string('modele');
        $table->timestamps();
    });
}
};
