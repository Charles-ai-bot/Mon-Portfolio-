<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    // database/seeders/DatabaseSeeder.php
public function run(): void
{
    \App\Models\Vehicule::factory(10)->create();
    \App\Models\Technicien::factory(5)->create();
    \App\Models\Reparation::factory(20)->create();
}
}
