<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Vehicule>
 */
class VehiculeFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
public function definition(): array
{
    return [
        'immatriculation' => $this->faker->regexify('[A-Z]{2}-\d{3}-[A-Z]{2}'),
        'marque' => $this->faker->randomElement(['Renault', 'Peugeot', 'Citroën', 'Toyota', 'Ford']),
        'modele' => $this->faker->word(),
    ];
}
}
