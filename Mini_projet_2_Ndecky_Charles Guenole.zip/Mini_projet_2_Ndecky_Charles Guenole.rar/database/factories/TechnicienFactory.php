<?php

namespace Database\Factories;

use App\Models\Technicien;
use Illuminate\Database\Eloquent\Factories\Factory;

class TechnicienFactory extends Factory
{
    protected $model = Technicien::class;

    public function definition(): array
    {
        return [
            'nom' => $this->faker->lastName(),
            'prenom' => $this->faker->firstName(),
            'specialite' => $this->faker->randomElement([
                'Mécanique',
                'Carrosserie', 
                'Électricité',
                'Diagnostic'
            ]),
        ];
    }
}