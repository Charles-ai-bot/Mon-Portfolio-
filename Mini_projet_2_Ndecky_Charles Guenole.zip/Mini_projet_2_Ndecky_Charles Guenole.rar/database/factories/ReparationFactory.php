<?php

namespace Database\Factories;

use App\Models\Reparation;
use App\Models\Vehicule;
use Illuminate\Database\Eloquent\Factories\Factory;

class ReparationFactory extends Factory
{
    protected $model = Reparation::class;

    public function definition(): array
    {
        return [
            'vehicule_id' => Vehicule::factory(),
            'date' => $this->faker->dateTimeBetween('-1 year', 'now'),
            'duree_main_oeuvre' => $this->faker->numberBetween(1, 8),
            'objet_reparation' => $this->faker->randomElement([
                'Vidange',
                'Changement plaquettes de frein',
                'Révision générale',
                'Changement pneus',
                'Diagnostic électronique',
            ]),
        ];
    }
}