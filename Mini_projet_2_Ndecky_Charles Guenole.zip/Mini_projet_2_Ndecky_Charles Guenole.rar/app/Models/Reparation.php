<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory; 
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Reparation extends Model
{
    use HasFactory; 
    
    protected $fillable = ['vehicule_id', 'date', 'duree_main_oeuvre', 'objet_reparation'];
    
    public function vehicule(): BelongsTo
    {
        return $this->belongsTo(Vehicule::class);
    }
    
    public function techniciens(): BelongsToMany
    {
        return $this->belongsToMany(Technicien::class);
    }
}