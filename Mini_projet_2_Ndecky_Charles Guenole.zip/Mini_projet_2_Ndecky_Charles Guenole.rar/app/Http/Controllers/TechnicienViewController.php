<?php

namespace App\Http\Controllers;

use App\Models\Technicien;
use Illuminate\Http\Request;

class TechnicienViewController extends Controller
{
    public function index()
    {
        $techniciens = Technicien::withCount('reparations')->get();
        return view('techniciens.index', compact('techniciens'));
    }
    
    public function create()
    {
        return view('techniciens.create');
    }
    
    public function store(Request $request)
    {
        $request->validate([
            'nom' => 'required|string|max:100',
            'prenom' => 'required|string|max:100',
            'specialite' => 'required|string|max:100',
        ]);
        
        Technicien::create($request->all());
        return redirect()->route('techniciens-web.index')->with('success', 'Technicien créé avec succès.');
    }
    
    public function show(Technicien $techniciens_web) // Correction du paramètre
    {
        $technicien = $techniciens_web;
        $technicien->load('reparations.vehicule');
        return view('techniciens.show', compact('technicien'));
    }
    
    public function edit(Technicien $techniciens_web)
    {
        $technicien = $techniciens_web;
        return view('techniciens.edit', compact('technicien'));
    }
    
    public function update(Request $request, Technicien $techniciens_web)
    {
        $request->validate([
            'nom' => 'required|string|max:100',
            'prenom' => 'required|string|max:100',
            'specialite' => 'required|string|max:100',
        ]);
        
        $techniciens_web->update($request->all());
        return redirect()->route('techniciens-web.index')->with('success', 'Technicien mis à jour avec succès.');
    }
    
    public function destroy(Technicien $techniciens_web)
    {
        $techniciens_web->delete();
        return redirect()->route('techniciens-web.index')->with('success', 'Technicien supprimé avec succès.');
    }
}