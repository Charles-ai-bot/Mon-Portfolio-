<?php

namespace App\Http\Controllers;

use App\Models\Reparation;
use App\Models\Vehicule;
use App\Models\Technicien;
use Illuminate\Http\Request;

class ReparationViewController extends Controller
{
    public function index()
    {
        // SOLUTION 1: Avec pagination (RECOMMANDÉ)
        $reparations = Reparation::with(['vehicule', 'techniciens'])
            ->latest()
            ->paginate(10); // ← CHANGEZ get() en paginate(10)
        
        // SOLUTION 2: Sans pagination (si vous préférez)
        // $reparations = Reparation::with(['vehicule', 'techniciens'])
        //     ->latest()
        //     ->get();
        
        return view('reparations.index', compact('reparations'));
    }
    
    public function create()
    {
        $vehicules = Vehicule::all();
        $techniciens = Technicien::all();
        return view('reparations.create', compact('vehicules', 'techniciens'));
    }
    
    public function store(Request $request)
    {
        $request->validate([
            'vehicule_id' => 'required|exists:vehicules,id',
            'date' => 'required|date',
            'duree_main_oeuvre' => 'required|integer|min:1|max:24',
            'objet_reparation' => 'required|string|min:3|max:500',
            'technicien_ids' => 'array',
            'technicien_ids.*' => 'exists:techniciens,id'
        ]);
        
        $reparation = Reparation::create([
            'vehicule_id' => $request->vehicule_id,
            'date' => $request->date,
            'duree_main_oeuvre' => $request->duree_main_oeuvre,
            'objet_reparation' => $request->objet_reparation,
        ]);
        
        if ($request->has('technicien_ids')) {
            $reparation->techniciens()->attach($request->technicien_ids);
        }
        
        return redirect()->route('reparations-web.index')->with('success', 'Réparation créée avec succès.');
    }
    
    public function show(Reparation $reparations_web)
    {
        $reparation = $reparations_web;
        $reparation->load(['vehicule', 'techniciens']);
        return view('reparations.show', compact('reparation'));
    }
    
    public function edit(Reparation $reparations_web)
    {
        $reparation = $reparations_web;
        $vehicules = Vehicule::all();
        $techniciens = Technicien::all();
        $reparation->load('techniciens');
        
        return view('reparations.edit', compact('reparation', 'vehicules', 'techniciens'));
    }
    
    public function update(Request $request, Reparation $reparations_web)
    {
        $request->validate([
            'vehicule_id' => 'required|exists:vehicules,id',
            'date' => 'required|date',
            'duree_main_oeuvre' => 'required|integer|min:1|max:24',
            'objet_reparation' => 'required|string|min:3|max:500',
            'technicien_ids' => 'array',
            'technicien_ids.*' => 'exists:techniciens,id'
        ]);
        
        $reparations_web->update([
            'vehicule_id' => $request->vehicule_id,
            'date' => $request->date,
            'duree_main_oeuvre' => $request->duree_main_oeuvre,
            'objet_reparation' => $request->objet_reparation,
        ]);
        
        $reparations_web->techniciens()->sync($request->technicien_ids ?? []);
        
        return redirect()->route('reparations-web.index')->with('success', 'Réparation mise à jour avec succès.');
    }
    
    public function destroy(Reparation $reparations_web)
    {
        $reparations_web->techniciens()->detach();
        $reparations_web->delete();
        return redirect()->route('reparations-web.index')->with('success', 'Réparation supprimée avec succès.');
    }
}