<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Reparation;
use App\Models\Vehicule;
use App\Models\Technicien;
use Illuminate\Http\Request;

class ReparationController extends Controller
{
    public function index()
    {
        return response()->json(Reparation::with(['vehicule', 'techniciens'])->get());
    }
    
    public function store(Request $request)
    {
        $validated = $request->validate([
            'vehicule_id' => 'required|exists:vehicules,id',
            'date' => 'required|date',
            'duree_main_oeuvre' => 'required|integer|min:1',
            'objet_reparation' => 'required|string|max:255',
            'technicien_ids' => 'array',
            'technicien_ids.*' => 'exists:techniciens,id',
        ]);
        
        $reparation = Reparation::create($validated);
        
        // Associer les techniciens si fournis
        if (isset($validated['technicien_ids'])) {
            $reparation->techniciens()->attach($validated['technicien_ids']);
        }
        
        return response()->json($reparation->load(['vehicule', 'techniciens']), 201);
    }
    
    public function show(Reparation $reparation)
    {
        return response()->json($reparation->load(['vehicule', 'techniciens']));
    }
    
    public function update(Request $request, Reparation $reparation)
    {
        $validated = $request->validate([
            'vehicule_id' => 'exists:vehicules,id',
            'date' => 'date',
            'duree_main_oeuvre' => 'integer|min:1',
            'objet_reparation' => 'string|max:255',
            'technicien_ids' => 'array',
            'technicien_ids.*' => 'exists:techniciens,id',
        ]);
        
        $reparation->update($validated);
        
        // Mettre à jour les techniciens si fournis
        if (isset($validated['technicien_ids'])) {
            $reparation->techniciens()->sync($validated['technicien_ids']);
        }
        
        return response()->json($reparation->load(['vehicule', 'techniciens']));
    }
    
    public function destroy(Reparation $reparation)
    {
        $reparation->delete();
        return response()->json(null, 204);
    }
    
    // Méthode pour ajouter un technicien à une réparation
    public function addTechnicien(Request $request, Reparation $reparation)
    {
        $validated = $request->validate([
            'technicien_id' => 'required|exists:techniciens,id',
        ]);
        
        $reparation->techniciens()->attach($validated['technicien_id']);
        return response()->json($reparation->load('techniciens'));
    }
    
    // Méthode pour retirer un technicien d'une réparation
    public function removeTechnicien(Reparation $reparation, Technicien $technicien)
    {
        $reparation->techniciens()->detach($technicien->id);
        return response()->json($reparation->load('techniciens'));
    }
}