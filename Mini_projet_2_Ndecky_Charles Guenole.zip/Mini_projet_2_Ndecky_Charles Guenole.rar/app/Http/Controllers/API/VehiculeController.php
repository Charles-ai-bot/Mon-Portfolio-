<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Vehicule;
use Illuminate\Http\Request;

class VehiculeController extends Controller
{
    public function index()
    {
        return response()->json(Vehicule::all());
    }
    
    public function store(Request $request)
    {
        $validated = $request->validate([
            'immatriculation' => 'required|string|max:20',
            'marque' => 'required|string|max:100',
            'modele' => 'required|string|max:100',
        ]);
        
        $vehicule = Vehicule::create($validated);
        return response()->json($vehicule, 201);
    }
    
    public function show(Vehicule $vehicule)
    {
        return response()->json($vehicule);
    }
    
    public function update(Request $request, Vehicule $vehicule)
    {
        $validated = $request->validate([
            'immatriculation' => 'string|max:20',
            'marque' => 'string|max:100',
            'modele' => 'string|max:100',
        ]);
        
        $vehicule->update($validated);
        return response()->json($vehicule);
    }
    
    public function destroy(Vehicule $vehicule)
    {
        $vehicule->delete();
        return response()->json(null, 204);
    }
}