<?php

namespace App\Http\Controllers;

use App\Models\Vehicule;
use Illuminate\Http\Request;

class VehiculeViewController extends Controller
{
    public function index()
    {
        $vehicules = Vehicule::withCount('reparations')->get();
        return view('vehicules.index', compact('vehicules'));
    }

    public function create()
    {
        return view('vehicules.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'immatriculation' => 'required|string|max:20|unique:vehicules',
            'marque' => 'required|string|max:100',
            'modele' => 'required|string|max:100',
        ]);
        
        Vehicule::create($request->all());
        return redirect()->route('vehicules-web.index')->with('success', 'Véhicule créé avec succès.');
    }

    public function show(Vehicule $vehicules_web) // IMPORTANT: paramètre doit correspondre au nom de route
    {
        $vehicule = $vehicules_web;
        $vehicule->load('reparations.techniciens');
        return view('vehicules.show', compact('vehicule'));
    }

    public function edit(Vehicule $vehicules_web)
    {
        $vehicule = $vehicules_web;
        return view('vehicules.edit', compact('vehicule'));
    }

    public function update(Request $request, Vehicule $vehicules_web)
    {
        $request->validate([
            'immatriculation' => 'required|string|max:20|unique:vehicules,immatriculation,' . $vehicules_web->id,
            'marque' => 'required|string|max:100',
            'modele' => 'required|string|max:100',
        ]);
        
        $vehicules_web->update($request->all());
        return redirect()->route('vehicules-web.index')->with('success', 'Véhicule mis à jour avec succès.');
    }

    public function destroy(Vehicule $vehicules_web)
    {
        $vehicules_web->delete();
        return redirect()->route('vehicules-web.index')->with('success', 'Véhicule supprimé avec succès.');
    }
}