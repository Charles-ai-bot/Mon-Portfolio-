<?php

use Illuminate\Support\Facades\Route;
use App\Models\Vehicule;
use App\Models\Technicien;
use App\Models\Reparation;

// Page d'accueil avec statistiques
Route::get('/', function () {
    $stats = [
        'vehicules' => Vehicule::count(),
        'techniciens' => Technicien::count(),
        'reparations' => Reparation::count(),
    ];
    return view('welcome', compact('stats'));
});

// Visualiseur d'API
Route::get('/api-viewer', function () {
    return view('api.viewer');
});

// Routes web pour l'interface navigateur
Route::resource('vehicules-web', \App\Http\Controllers\VehiculeViewController::class);
Route::resource('techniciens-web', \App\Http\Controllers\TechnicienViewController::class);
Route::resource('reparations-web', \App\Http\Controllers\ReparationViewController::class);