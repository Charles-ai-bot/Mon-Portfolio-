<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\VehiculeController;
use App\Http\Controllers\API\TechnicienController;
use App\Http\Controllers\API\ReparationController;

Route::apiResource('vehicules', VehiculeController::class);
Route::apiResource('techniciens', TechnicienController::class);
Route::apiResource('reparations', ReparationController::class);

// Routes supplémentaires
Route::get('techniciens/{technicien}/reparations', [TechnicienController::class, 'reparations']);
Route::post('reparations/{reparation}/techniciens', [ReparationController::class, 'addTechnicien']);
Route::delete('reparations/{reparation}/techniciens/{technicien}', [ReparationController::class, 'removeTechnicien']);
