

<?php $__env->startSection('title', 'Liste des Techniciens'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
        <h4 class="mb-0">
            <i class="bi bi-person-badge me-2"></i>Liste des Techniciens
        </h4>
        <a href="<?php echo e(route('techniciens-web.create')); ?>" class="btn btn-light btn-sm">
            <i class="bi bi-person-plus me-1"></i> Nouveau
        </a>
    </div>
    
    <div class="card-body">
        <?php if($techniciens->isEmpty()): ?>
        <div class="text-center py-5">
            <i class="bi bi-people display-1 text-muted"></i>
            <h5 class="mt-3 text-muted">Aucun technicien enregistré</h5>
            <a href="<?php echo e(route('techniciens-web.create')); ?>" class="btn btn-primary">
                <i class="bi bi-person-plus me-1"></i> Ajouter un technicien
            </a>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th width="80">ID</th>
                        <th>Nom & Prénom</th>
                        <th>Spécialité</th>
                        <th class="mobile-hidden">Date création</th>
                        <th width="180" class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $techniciens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technicien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <span class="badge bg-secondary">#<?php echo e($technicien->id); ?></span>
                        </td>
                        <td>
                            <strong><?php echo e($technicien->prenom); ?> <?php echo e($technicien->nom); ?></strong>
                        </td>
                        <td>
                            <?php
                                $specialiteColors = [
                                    'Mécanique' => 'danger',
                                    'Carrosserie' => 'warning',
                                    'Électricité' => 'info',
                                    'Diagnostic' => 'success',
                                    'Peinture' => 'primary'
                                ];
                                $color = $specialiteColors[$technicien->specialite] ?? 'secondary';
                            ?>
                            <span class="badge bg-<?php echo e($color); ?>">
                                <?php echo e($technicien->specialite); ?>

                            </span>
                        </td>
                        <td class="mobile-hidden">
                            <small class="text-muted"><?php echo e($technicien->created_at->format('d/m/Y')); ?></small>
                        </td>
                        <td class="action-buttons">
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('techniciens-web.show', $technicien)); ?>" 
                                   class="btn btn-outline-info btn-sm"
                                   title="Voir détails">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <a href="<?php echo e(route('techniciens-web.edit', $technicien)); ?>" 
                                   class="btn btn-outline-warning btn-sm"
                                   title="Modifier">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="<?php echo e(route('techniciens-web.destroy', $technicien)); ?>" 
                                      method="POST" 
                                      class="d-inline"
                                      onsubmit="return confirm('Supprimer ce technicien ?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" 
                                            class="btn btn-outline-danger btn-sm"
                                            title="Supprimer">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mt-3 pt-3 border-top">
            <div class="mb-2 mb-md-0">
                <span class="text-muted">
                    <i class="bi bi-info-circle me-1"></i>
                    Total : <strong><?php echo e($techniciens->count()); ?></strong> technicien(s)
                </span>
            </div>
            <div>
                <a href="<?php echo e(url('/api/techniciens')); ?>" target="_blank" class="btn btn-outline-secondary btn-sm me-2">
                    <i class="bi bi-code-slash me-1"></i> API
                </a>
                <a href="<?php echo e(route('techniciens-web.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="bi bi-person-plus me-1"></i> Ajouter
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bmd tech\Desktop\xampp\htdocs\gestion_garage\resources\views/techniciens/index.blade.php ENDPATH**/ ?>