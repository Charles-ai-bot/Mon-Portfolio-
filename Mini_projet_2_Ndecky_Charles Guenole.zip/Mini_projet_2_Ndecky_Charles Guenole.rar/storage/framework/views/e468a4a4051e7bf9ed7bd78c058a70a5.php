

<?php $__env->startSection('title', 'Liste des Véhicules'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <h4 class="mb-0">
            <i class="bi bi-truck me-2"></i>Liste des Véhicules
        </h4>
        <a href="<?php echo e(route('vehicules-web.create')); ?>" class="btn btn-light btn-sm">
            <i class="bi bi-plus-circle me-1"></i> Nouveau
        </a>
    </div>
    
    <div class="card-body">
        <?php if($vehicules->isEmpty()): ?>
        <div class="text-center py-5">
            <i class="bi bi-car-front display-1 text-muted"></i>
            <h5 class="mt-3 text-muted">Aucun véhicule enregistré</h5>
            <p class="text-muted">Commencez par ajouter votre premier véhicule</p>
            <a href="<?php echo e(route('vehicules-web.create')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-circle me-1"></i> Ajouter un véhicule
            </a>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th width="80">ID</th>
                        <th>Immatriculation</th>
                        <th class="mobile-hidden">Marque</th>
                        <th class="mobile-hidden">Modèle</th>
                        <th class="mobile-hidden">Date création</th>
                        <th width="180" class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $vehicules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <span class="badge bg-secondary">#<?php echo e($vehicule->id); ?></span>
                        </td>
                        <td>
                            <strong class="text-primary"><?php echo e($vehicule->immatriculation); ?></strong>
                            <div class="text-muted small d-block d-md-none">
                                <?php echo e($vehicule->marque); ?> <?php echo e($vehicule->modele); ?>

                            </div>
                        </td>
                        <td class="mobile-hidden"><?php echo e($vehicule->marque); ?></td>
                        <td class="mobile-hidden"><?php echo e($vehicule->modele); ?></td>
                        <td class="mobile-hidden">
                            <small class="text-muted"><?php echo e($vehicule->created_at->format('d/m/Y')); ?></small>
                        </td>
                        <td class="action-buttons">
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('vehicules-web.show', $vehicule)); ?>" 
                                   class="btn btn-outline-info btn-sm" 
                                   title="Voir détails"
                                   data-bs-toggle="tooltip">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <a href="<?php echo e(route('vehicules-web.edit', $vehicule)); ?>" 
                                   class="btn btn-outline-warning btn-sm"
                                   title="Modifier"
                                   data-bs-toggle="tooltip">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <form action="<?php echo e(route('vehicules-web.destroy', $vehicule)); ?>" 
                                      method="POST" 
                                      class="d-inline"
                                      onsubmit="return confirm('Supprimer définitivement ce véhicule ?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" 
                                            class="btn btn-outline-danger btn-sm"
                                            title="Supprimer"
                                            data-bs-toggle="tooltip">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mt-3 pt-3 border-top">
            <div class="mb-2 mb-md-0">
                <span class="text-muted">
                    <i class="bi bi-info-circle me-1"></i>
                    Total : <strong><?php echo e($vehicules->count()); ?></strong> véhicule(s)
                </span>
            </div>
            <div>
                <a href="<?php echo e(url('/api/vehicules')); ?>" target="_blank" class="btn btn-outline-secondary btn-sm me-2">
                    <i class="bi bi-code-slash me-1"></i> Voir API
                </a>
                <a href="<?php echo e(route('vehicules-web.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="bi bi-plus-circle me-1"></i> Ajouter
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
    // Activer les tooltips Bootstrap
    document.addEventListener('DOMContentLoaded', function() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        })
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bmd tech\Desktop\xampp\htdocs\gestion_garage\resources\views/vehicules/index.blade.php ENDPATH**/ ?>