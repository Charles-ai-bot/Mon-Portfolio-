

<?php $__env->startSection('title', 'Détails Réparation'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Détails de la Réparation</h1>
    <div class="btn-group">
        <a href="<?php echo e(route('reparations-web.edit', $reparation)); ?>" class="btn btn-warning">
            <i class="bi bi-pencil"></i> Modifier
        </a>
        <a href="<?php echo e(route('reparations-web.index')); ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Retour
        </a>
    </div>
</div>

<div class="card">
    <div class="card-header bg-success text-white">
        <h5 class="mb-0">Informations de la réparation</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <p><strong>ID:</strong> #<?php echo e($reparation->id); ?></p>
                <p><strong>Véhicule:</strong> 
                    <a href="<?php echo e(route('vehicules-web.show', $reparation->vehicule)); ?>" class="text-decoration-none">
                        <i class="bi bi-car-front"></i>
                        <?php echo e($reparation->vehicule->immatriculation); ?>

                        (<?php echo e($reparation->vehicule->marque); ?> <?php echo e($reparation->vehicule->modele); ?>)
                    </a>
                </p>
                <p><strong>Date:</strong> <?php echo e(\Carbon\Carbon::parse($reparation->date)->format('d/m/Y H:i')); ?></p>
                <p><strong>Durée:</strong> <span class="badge bg-warning text-dark"><?php echo e($reparation->duree_main_oeuvre); ?> heures</span></p>
            </div>
            <div class="col-md-6">
                <p><strong>Objet:</strong> <?php echo e($reparation->objet_reparation); ?></p>
                <p><strong>Créé le:</strong> <?php echo e($reparation->created_at->format('d/m/Y H:i')); ?></p>
                <p><strong>Modifié le:</strong> <?php echo e($reparation->updated_at->format('d/m/Y H:i')); ?></p>
            </div>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h5 class="mb-0">Techniciens assignés</h5>
    </div>
    <div class="card-body">
        <?php if($reparation->techniciens->isEmpty()): ?>
            <div class="alert alert-info">Aucun technicien assigné.</div>
        <?php else: ?>
            <div class="row">
                <?php $__currentLoopData = $reparation->techniciens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technicien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-6 mb-3">
                        <div class="card h-100">
                            <div class="card-body text-center">
                                <h6 class="card-title"><?php echo e($technicien->prenom); ?> <?php echo e($technicien->nom); ?></h6>
                                <span class="badge bg-info"><?php echo e($technicien->specialite); ?></span>
                                <div class="mt-2">
                                    <a href="<?php echo e(route('techniciens-web.show', $technicien)); ?>" 
                                       class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-person"></i> Voir profil
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="mt-3">
    <form action="<?php echo e(route('reparations-web.destroy', $reparation)); ?>" method="POST" 
          onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer cette réparation ?');">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger">
            <i class="bi bi-trash"></i> Supprimer cette réparation
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bmd tech\Desktop\xampp\htdocs\gestion_garage\resources\views/reparations/show.blade.php ENDPATH**/ ?>