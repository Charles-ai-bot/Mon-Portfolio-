

<?php $__env->startSection('title', 'Nouveau Véhicule'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Nouveau Véhicule</h1>
    
    <form action="<?php echo e(route('vehicules-web.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <div class="mb-3">
            <label for="immatriculation" class="form-label">Immatriculation *</label>
            <input type="text" class="form-control" id="immatriculation" name="immatriculation" 
                   required placeholder="Ex: AB-123-CD" value="<?php echo e(old('immatriculation')); ?>">
        </div>
        
        <div class="mb-3">
            <label for="marque" class="form-label">Marque *</label>
            <input type="text" class="form-control" id="marque" name="marque" 
                   required placeholder="Ex: Renault" value="<?php echo e(old('marque')); ?>">
        </div>
        
        <div class="mb-3">
            <label for="modele" class="form-label">Modèle *</label>
            <input type="text" class="form-control" id="modele" name="modele" 
                   required placeholder="Ex: Clio" value="<?php echo e(old('modele')); ?>">
        </div>
        
        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">Créer</button>
            <a href="<?php echo e(route('vehicules-web.index')); ?>" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bmd tech\Desktop\xampp\htdocs\gestion_garage\resources\views/vehicules/create.blade.php ENDPATH**/ ?>