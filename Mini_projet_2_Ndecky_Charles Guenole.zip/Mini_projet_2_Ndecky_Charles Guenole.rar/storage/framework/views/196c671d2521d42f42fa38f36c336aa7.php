

<?php $__env->startSection('title', 'Modifier Réparation'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-warning text-dark">
        <h4 class="mb-0">
            <i class="bi bi-pencil-square"></i> Modifier la Réparation #<?php echo e($reparation->id); ?>

        </h4>
    </div>
    
    <div class="card-body">
        <form action="<?php echo e(route('reparations-web.update', $reparation)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="vehicule_id" class="form-label">Véhicule *</label>
                    <select class="form-select <?php $__errorArgs = ['vehicule_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            id="vehicule_id" name="vehicule_id" required>
                        <option value="">Sélectionner un véhicule</option>
                        <?php $__currentLoopData = $vehicules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($vehicule->id); ?>" 
                                <?php echo e(old('vehicule_id', $reparation->vehicule_id) == $vehicule->id ? 'selected' : ''); ?>>
                                <?php echo e($vehicule->immatriculation); ?> - <?php echo e($vehicule->marque); ?> <?php echo e($vehicule->modele); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['vehicule_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="date" class="form-label">Date *</label>
                    <input type="datetime-local" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           id="date" name="date" 
                           value="<?php echo e(old('date', \Carbon\Carbon::parse($reparation->date)->format('Y-m-d\TH:i'))); ?>" 
                           required>
                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="duree_main_oeuvre" class="form-label">Durée (heures) *</label>
                    <input type="number" class="form-control <?php $__errorArgs = ['duree_main_oeuvre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           id="duree_main_oeuvre" name="duree_main_oeuvre" 
                           min="1" max="24" step="0.5"
                           value="<?php echo e(old('duree_main_oeuvre', $reparation->duree_main_oeuvre)); ?>" 
                           required>
                    <?php $__errorArgs = ['duree_main_oeuvre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="objet_reparation" class="form-label">Objet de la réparation *</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['objet_reparation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           id="objet_reparation" name="objet_reparation" 
                           value="<?php echo e(old('objet_reparation', $reparation->objet_reparation)); ?>" 
                           required placeholder="Ex: Vidange, Freins, Carrosserie...">
                    <?php $__errorArgs = ['objet_reparation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            <div class="mb-4">
                <label class="form-label fw-bold">Techniciens assignés *</label>
                <div class="border p-3 rounded">
                    <div class="row">
                        <?php $__currentLoopData = $techniciens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technicien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 col-sm-4 mb-2">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" 
                                           name="technicien_ids[]" 
                                           value="<?php echo e($technicien->id); ?>" 
                                           id="tech<?php echo e($technicien->id); ?>"
                                           <?php echo e(in_array($technicien->id, old('technicien_ids', $reparation->techniciens->pluck('id')->toArray())) ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="tech<?php echo e($technicien->id); ?>">
                                        <strong><?php echo e($technicien->prenom); ?> <?php echo e($technicien->nom); ?></strong>
                                        <small class="text-muted d-block"><?php echo e($technicien->specialite); ?></small>
                                    </label>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            
            <div class="d-flex justify-content-between">
                <div>
                    <a href="<?php echo e(route('reparations-web.show', $reparation)); ?>" class="btn btn-secondary me-2">
                        <i class="bi bi-x-circle"></i> Annuler
                    </a>
                    <button type="submit" class="btn btn-warning">
                        <i class="bi bi-check-circle"></i> Mettre à jour
                    </button>
                </div>
                
                <a href="<?php echo e(route('reparations-web.index')); ?>" class="btn btn-outline-primary">
                    <i class="bi bi-list"></i> Retour à la liste
                </a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bmd tech\Desktop\xampp\htdocs\gestion_garage\resources\views/reparations/edit.blade.php ENDPATH**/ ?>