

<?php $__env->startSection('title', 'Nouvelle Réparation'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Nouvelle Réparation</h1>
    
    <form action="<?php echo e(route('reparations-web.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="vehicule_id" class="form-label">Véhicule *</label>
                <select class="form-select" id="vehicule_id" name="vehicule_id" required>
                    <option value="">Sélectionner un véhicule</option>
                    <?php $__currentLoopData = $vehicules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($vehicule->id); ?>" <?php echo e(old('vehicule_id') == $vehicule->id ? 'selected' : ''); ?>>
                            <?php echo e($vehicule->immatriculation); ?> - <?php echo e($vehicule->marque); ?> <?php echo e($vehicule->modele); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            
            <div class="col-md-6 mb-3">
                <label for="date" class="form-label">Date *</label>
                <input type="datetime-local" class="form-control" id="date" name="date" 
                       value="<?php echo e(old('date', now()->format('Y-m-d\TH:i'))); ?>" required>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="duree_main_oeuvre" class="form-label">Durée (heures) *</label>
                <input type="number" class="form-control" id="duree_main_oeuvre" name="duree_main_oeuvre" 
                       min="1" max="24" value="<?php echo e(old('duree_main_oeuvre', 1)); ?>" required>
            </div>
            
            <div class="col-md-6 mb-3">
                <label for="objet_reparation" class="form-label">Objet de la réparation *</label>
                <input type="text" class="form-control" id="objet_reparation" name="objet_reparation" 
                       value="<?php echo e(old('objet_reparation')); ?>" required placeholder="Ex: Vidange, Freins...">
            </div>
        </div>
        
        <div class="mb-3">
            <label class="form-label">Techniciens assignés</label>
            <div class="row">
                <?php $__currentLoopData = $techniciens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technicien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 mb-2">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" 
                                   name="technicien_ids[]" 
                                   value="<?php echo e($technicien->id); ?>" 
                                   id="tech<?php echo e($technicien->id); ?>">
                            <label class="form-check-label" for="tech<?php echo e($technicien->id); ?>">
                                <?php echo e($technicien->prenom); ?> <?php echo e($technicien->nom); ?>

                                <small class="text-muted d-block"><?php echo e($technicien->specialite); ?></small>
                            </label>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        
        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">Créer la réparation</button>
            <a href="<?php echo e(route('reparations-web.index')); ?>" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bmd tech\Desktop\xampp\htdocs\gestion_garage\resources\views/reparations/create.blade.php ENDPATH**/ ?>