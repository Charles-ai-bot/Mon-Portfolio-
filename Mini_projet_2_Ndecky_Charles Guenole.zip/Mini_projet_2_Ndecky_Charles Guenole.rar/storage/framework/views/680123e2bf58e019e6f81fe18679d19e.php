

<?php $__env->startSection('title', 'Détails Technicien'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Détails du Technicien</h1>
    <div class="btn-group">
        <a href="<?php echo e(route('techniciens-web.edit', $technicien)); ?>" class="btn btn-warning">
            <i class="bi bi-pencil"></i> Modifier
        </a>
        <a href="<?php echo e(route('techniciens-web.index')); ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Retour
        </a>
    </div>
</div>

<div class="card">
    <div class="card-header bg-info text-white">
        <h5 class="mb-0">Informations du technicien</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <p><strong>ID:</strong> <?php echo e($technicien->id); ?></p>
                <p><strong>Nom:</strong> <?php echo e($technicien->nom); ?></p>
                <p><strong>Prénom:</strong> <?php echo e($technicien->prenom); ?></p>
                <p><strong>Spécialité:</strong> 
                    <span class="badge bg-primary"><?php echo e($technicien->specialite); ?></span>
                </p>
            </div>
            <div class="col-md-6">
                <p><strong>Créé le:</strong> <?php echo e($technicien->created_at->format('d/m/Y H:i')); ?></p>
                <p><strong>Modifié le:</strong> <?php echo e($technicien->updated_at->format('d/m/Y H:i')); ?></p>
                <p><strong>Nombre de réparations:</strong> 
                    <span class="badge bg-info"><?php echo e($technicien->reparations_count); ?></span>
                </p>
            </div>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h5 class="mb-0">Réparations assignées</h5>
    </div>
    <div class="card-body">
        <?php if($technicien->reparations->isEmpty()): ?>
            <div class="alert alert-info">Aucune réparation assignée à ce technicien.</div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-sm table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Date</th>
                            <th>Véhicule</th>
                            <th>Objet</th>
                            <th>Durée</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $technicien->reparations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reparation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>#<?php echo e($reparation->id); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($reparation->date)->format('d/m/Y')); ?></td>
                                <td>
                                    <strong><?php echo e($reparation->vehicule->immatriculation); ?></strong>
                                    <small class="text-muted d-block"><?php echo e($reparation->vehicule->marque); ?></small>
                                </td>
                                <td><?php echo e(Str::limit($reparation->objet_reparation, 30)); ?></td>
                                <td><?php echo e($reparation->duree_main_oeuvre); ?>h</td>
                                <td>
                                    <a href="<?php echo e(route('reparations-web.show', $reparation)); ?>" 
                                       class="btn btn-sm btn-outline-info">
                                        Voir
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="mt-3">
    <form action="<?php echo e(route('techniciens-web.destroy', $technicien)); ?>" method="POST" 
          onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer ce technicien ?');">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger">
            <i class="bi bi-trash"></i> Supprimer ce technicien
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bmd tech\Desktop\xampp\htdocs\gestion_garage\resources\views/techniciens/show.blade.php ENDPATH**/ ?>