

<?php $__env->startSection('title', 'Liste des Réparations'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold">Liste des Réparations</h3>
        <a href="<?php echo e(route('reparations-web.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Nouvelle réparation
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle-fill"></i> <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if($reparations->isEmpty()): ?>
        <div class="text-center py-5">
            <i class="bi bi-tools display-1 text-muted"></i>
            <h4 class="mt-3 text-muted">Aucune réparation enregistrée</h4>
            <p class="text-muted">Commencez par ajouter votre première réparation</p>
            <a href="<?php echo e(route('reparations-web.create')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i> Ajouter une réparation
            </a>
        </div>
    <?php else: ?>
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-primary">
                            <tr>
                                <th>ID</th>
                                <th>Véhicule</th>
                                <th class="d-none d-md-table-cell">Date</th>
                                <th>Durée</th>
                                <th>Objet</th>
                                <th class="d-none d-sm-table-cell">Techniciens</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reparations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reparation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <span class="badge bg-secondary">#<?php echo e($reparation->id); ?></span>
                                    </td>
                                    <td>
                                        <div class="fw-bold"><?php echo e($reparation->vehicule->immatriculation ?? 'N/A'); ?></div>
                                        <small class="text-muted"><?php echo e($reparation->vehicule->marque ?? ''); ?> <?php echo e($reparation->vehicule->modele ?? ''); ?></small>
                                    </td>
                                    <td class="d-none d-md-table-cell">
                                        <?php echo e(\Carbon\Carbon::parse($reparation->date)->format('d/m/Y')); ?>

                                    </td>
                                    <td>
                                        <span class="badge bg-warning text-dark">
                                            <?php echo e($reparation->duree_main_oeuvre ?? $reparation->duree); ?>h
                                        </span>
                                    </td>
                                    <td>
                                        <span title="<?php echo e($reparation->objet_reparation ?? $reparation->objet); ?>">
                                            <?php echo e(Str::limit($reparation->objet_reparation ?? $reparation->objet, 30)); ?>

                                        </span>
                                    </td>
                                    <td class="d-none d-sm-table-cell">
                                        <?php $__empty_1 = true; $__currentLoopData = $reparation->techniciens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technicien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <span class="badge bg-info me-1">
                                                <?php echo e($technicien->prenom); ?>

                                            </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <span class="badge bg-secondary">Aucun</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('reparations-web.show', $reparation)); ?>" 
                                               class="btn btn-outline-info btn-sm"
                                               title="Voir détails">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('reparations-web.edit', $reparation)); ?>" 
                                               class="btn btn-outline-warning btn-sm"
                                               title="Modifier">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <form action="<?php echo e(route('reparations-web.destroy', $reparation)); ?>" 
                                                  method="POST" 
                                                  class="d-inline"
                                                  onsubmit="return confirm('Supprimer cette réparation ?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" 
                                                        class="btn btn-outline-danger btn-sm"
                                                        title="Supprimer">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <!-- PAGINATION (fonctionnera avec paginate()) -->
                <?php if($reparations->hasPages()): ?>
                    <div class="d-flex justify-content-center mt-4">
                        <?php echo e($reparations->links()); ?>

                    </div>
                <?php endif; ?>

                <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                    <div class="text-muted">
                        <i class="bi bi-info-circle"></i>
                        Total : <strong><?php echo e($reparations->total()); ?></strong> réparation(s)
                    </div>
                    <div>
                        <a href="/api/reparations" target="_blank" class="btn btn-outline-secondary btn-sm">
                            <i class="bi bi-code-slash"></i> Voir API
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bmd tech\Desktop\xampp\htdocs\gestion_garage\resources\views/reparations/index.blade.php ENDPATH**/ ?>