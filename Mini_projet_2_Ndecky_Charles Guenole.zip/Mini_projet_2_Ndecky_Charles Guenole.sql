-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 26 déc. 2025 à 22:16
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gestion_garage`
--

-- --------------------------------------------------------

--
-- Structure de la table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2025_12_26_113112_create_vehicules_table', 1),
(5, '2025_12_26_113113_create_techniciens_table', 1),
(6, '2025_12_26_113114_create_reparations_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `reparations`
--

CREATE TABLE `reparations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vehicule_id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `duree_main_oeuvre` varchar(255) NOT NULL,
  `objet_reparation` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `reparations`
--

INSERT INTO `reparations` (`id`, `vehicule_id`, `date`, `duree_main_oeuvre`, `objet_reparation`, `created_at`, `updated_at`) VALUES
(5, 15, '2025-01-31', '4', 'Diagnostic électronique', '2025-12-26 14:09:55', '2025-12-26 20:27:18'),
(9, 19, '2025-01-21', '8', 'Changement pneus', '2025-12-26 14:09:55', '2025-12-26 20:27:51'),
(15, 25, '2025-12-02', '3', 'Révision générale', '2025-12-26 14:09:56', '2025-12-26 20:25:25'),
(22, 2, '2025-12-26', '1', 'Vidange', '2025-12-26 20:22:12', '2025-12-26 20:22:12');

-- --------------------------------------------------------

--
-- Structure de la table `reparation_technicien`
--

CREATE TABLE `reparation_technicien` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `reparation_id` bigint(20) UNSIGNED NOT NULL,
  `technicien_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `reparation_technicien`
--

INSERT INTO `reparation_technicien` (`id`, `reparation_id`, `technicien_id`, `created_at`, `updated_at`) VALUES
(1, 22, 6, NULL, NULL),
(4, 15, 4, NULL, NULL),
(5, 5, 3, NULL, NULL),
(6, 9, 7, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('yOswtHFPXighPT6ggVLDPbm2yQ957avsXusD4HWn', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibzFva0xRdkxPMG9LQnd2WDlucGhpV1BUeVhoZ1M5S0pXSkNkVXIzciI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9yZXBhcmF0aW9ucy13ZWIiO3M6NToicm91dGUiO3M6MjE6InJlcGFyYXRpb25zLXdlYi5pbmRleCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1766782934);

-- --------------------------------------------------------

--
-- Structure de la table `techniciens`
--

CREATE TABLE `techniciens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `specialite` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `techniciens`
--

INSERT INTO `techniciens` (`id`, `nom`, `prenom`, `specialite`, `created_at`, `updated_at`) VALUES
(2, 'Wisozk', 'Francesco', 'Carrosserie', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(3, 'Sporer', 'Elza', 'Électricité', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(4, 'Little', 'Georgiana', 'Diagnostic', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(5, 'Yost', 'Brenda', 'Diagnostic', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(6, 'Paucek', 'Stone', 'Mécanique', '2025-12-26 15:40:35', '2025-12-26 15:40:35'),
(7, 'Paucek', 'Stone', 'Mécanique', '2025-12-26 15:42:36', '2025-12-26 15:42:36'),
(8, 'Paucek', 'Stone', 'Mécanique', '2025-12-26 15:46:23', '2025-12-26 15:46:23'),
(9, 'Paucek', 'Stone', 'Mécanique', '2025-12-26 15:47:56', '2025-12-26 15:47:56'),
(10, 'Paucek', 'Stone', 'Mécanique', '2025-12-26 15:49:55', '2025-12-26 15:49:55'),
(11, 'Paucek', 'Stone', 'Mécanique', '2025-12-26 16:04:17', '2025-12-26 16:04:17');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `vehicules`
--

CREATE TABLE `vehicules` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `immatriculation` varchar(255) NOT NULL,
  `marque` varchar(255) NOT NULL,
  `modele` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `vehicules`
--

INSERT INTO `vehicules` (`id`, `immatriculation`, `marque`, `modele`, `created_at`, `updated_at`) VALUES
(2, 'NN-444-IG', 'Toyota', 'eos', '2025-12-26 14:09:55', '2025-12-26 19:32:13'),
(3, 'PV-660-WF', 'Ford', 'ea', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(4, 'LG-654-XT', 'Ford', 'omnis', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(5, 'SB-068-MQ', 'Toyota', 'recusandae', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(6, 'ZM-723-DQ', 'Ford', 'quia', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(7, 'SP-793-KS', 'Renault', 'hic', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(8, 'LW-408-TP', 'Ford', 'est', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(9, 'UM-594-CP', 'Citroën', 'sed', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(10, 'PS-940-FE', 'Peugeot', 'est', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(11, 'GL-057-NQ', 'Toyota', 'repudiandae', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(12, 'EM-441-GX', 'Toyota', 'sint', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(13, 'KT-780-PL', 'Citroën', 'quia', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(14, 'WS-306-RB', 'Toyota', 'est', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(15, 'KQ-193-GS', 'Renault', 'iusto', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(17, 'YN-297-WR', 'Peugeot', 'dolor', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(18, 'QG-101-XV', 'Citroën', 'quo', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(19, 'ZA-575-VE', 'Renault', 'minus', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(20, 'XZ-252-BA', 'Peugeot', 'animi', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(21, 'BP-795-TF', 'Toyota', 'aliquam', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(22, 'HV-089-LV', 'Toyota', 'occaecati', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(23, 'IO-359-KY', 'Peugeot', 'enim', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(24, 'JQ-346-IC', 'Peugeot', 'voluptatem', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(25, 'VW-464-US', 'Citroën', 'id', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(26, 'FX-627-AW', 'Renault', 'atque', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(27, 'ZF-500-YE', 'Toyota', 'reprehenderit', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(28, 'US-273-CU', 'Citroën', 'impedit', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(29, 'DE-649-AC', 'Citroën', 'voluptas', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(30, 'FV-869-RA', 'Peugeot', 'ratione', '2025-12-26 14:09:55', '2025-12-26 14:09:55'),
(31, 'JQ-908-TM', 'Peugeot', 'et', '2025-12-26 15:52:50', '2025-12-26 15:52:50'),
(32, 'JQ-908-TM', 'Peugeot', 'et', '2025-12-26 15:53:05', '2025-12-26 15:53:05'),
(33, 'AB-234-BG', 'Renault', 'Clio', '2025-12-26 19:25:59', '2025-12-26 19:25:59');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Index pour la table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Index pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Index pour la table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Index pour la table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Index pour la table `reparations`
--
ALTER TABLE `reparations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reparations_vehicule_id_foreign` (`vehicule_id`);

--
-- Index pour la table `reparation_technicien`
--
ALTER TABLE `reparation_technicien`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reparation_technicien_reparation_id_foreign` (`reparation_id`),
  ADD KEY `reparation_technicien_technicien_id_foreign` (`technicien_id`);

--
-- Index pour la table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Index pour la table `techniciens`
--
ALTER TABLE `techniciens`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Index pour la table `vehicules`
--
ALTER TABLE `vehicules`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `reparations`
--
ALTER TABLE `reparations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT pour la table `reparation_technicien`
--
ALTER TABLE `reparation_technicien`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `techniciens`
--
ALTER TABLE `techniciens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `vehicules`
--
ALTER TABLE `vehicules`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `reparations`
--
ALTER TABLE `reparations`
  ADD CONSTRAINT `reparations_vehicule_id_foreign` FOREIGN KEY (`vehicule_id`) REFERENCES `vehicules` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `reparation_technicien`
--
ALTER TABLE `reparation_technicien`
  ADD CONSTRAINT `reparation_technicien_reparation_id_foreign` FOREIGN KEY (`reparation_id`) REFERENCES `reparations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reparation_technicien_technicien_id_foreign` FOREIGN KEY (`technicien_id`) REFERENCES `techniciens` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
