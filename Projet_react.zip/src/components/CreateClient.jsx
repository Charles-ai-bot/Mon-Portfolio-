import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const CreateClient = () => {
  const [client, setClient] = useState({ nom: "", adresse: "", tel: "" });
  const navigate = useNavigate();

  const handleCreate = async () => {
    try {
      await axios.post("http://localhost:3001/clients", client);
      navigate("/clients", { replace: true });
    } catch (error) {
      console.error("Erreur de création:", error);
      alert("Erreur lors de la création du client");
    }
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card border-dark" style={{ borderRadius: '0px' }}>
            <div className="card-header bg-dark text-white text-center">
              <h3 className="mb-0">Créer un Nouveau Client</h3>
            </div>
            
            <div className="card-body">
              <form>
                <div className="mb-3">
                  <label className="form-label fw-bold">Nom du client :</label>
                  <input
                    type="text"
                    className="form-control border-dark"
                    style={{ borderRadius: '0px' }}
                    value={client.nom}
                    onChange={(e) => setClient({ ...client, nom: e.target.value })}
                    placeholder="Entrez le nom du client"
                  />
                </div>

                <div className="mb-3">
                  <label className="form-label fw-bold">Adresse :</label>
                  <input
                    type="text"
                    className="form-control border-dark"
                    style={{ borderRadius: '0px' }}
                    value={client.adresse}
                    onChange={(e) => setClient({ ...client, adresse: e.target.value })}
                    placeholder="Entrez l'adresse"
                  />
                </div>

                <div className="mb-4">
                  <label className="form-label fw-bold">Téléphone :</label>
                  <input
                    type="text"
                    className="form-control border-dark"
                    style={{ borderRadius: '0px' }}
                    value={client.tel}
                    onChange={(e) => setClient({ ...client, tel: e.target.value })}
                    placeholder="Entrez le numéro de téléphone"
                  />
                </div>

                <div className="d-flex justify-content-between">
                  <button
                    type="button"
                    className="btn btn-secondary border-dark"
                    style={{ borderRadius: '0px', width: '48%' }}
                    onClick={() => navigate("/clients")}
                  >
                    Annuler
                  </button>
                  
                  <button
                    type="button"
                    className="btn btn-success border-dark fw-bold"
                    style={{ borderRadius: '0px', width: '48%' }}
                    onClick={handleCreate}
                  >
                    Créer
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateClient;