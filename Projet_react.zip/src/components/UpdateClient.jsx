import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const UpdateClient = () => {
  const { id } = useParams();
  const [client, setClient] = useState({ nom: '', adresse: '', tel: '' });
  const navigate = useNavigate();

  useEffect(() => {
    const fetchClient = async () => {
      try {
        const response = await axios.get(`http://localhost:3001/clients/${id}`);
        setClient(response.data);
      } catch (error) {
        console.error("Erreur de chargement:", error);
        alert("Client non trouvé");
      }
    };
    fetchClient();
  }, [id]);

  const handleUpdate = async () => {
    try {
      await axios.put(`http://localhost:3001/clients/${id}`, client);
      navigate('/clients');
    } catch (error) {
      console.error("Erreur de mise à jour:", error);
      alert("Erreur lors de la mise à jour");
    }
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card border-dark" style={{ borderRadius: '0px' }}>
            <div className="card-header bg-dark text-white text-center">
              <h3 className="mb-0">Modifier le Client</h3>
              <small className="text-light">ID: {id}</small>
            </div>
            
            <div className="card-body">
              <form>
                <div className="mb-3">
                  <label className="form-label fw-bold">Nom du client :</label>
                  <input
                    type="text"
                    className="form-control border-dark"
                    style={{ borderRadius: '0px' }}
                    value={client.nom}
                    onChange={(e) => setClient({ ...client, nom: e.target.value })}
                  />
                </div>

                <div className="mb-3">
                  <label className="form-label fw-bold">Adresse :</label>
                  <input
                    type="text"
                    className="form-control border-dark"
                    style={{ borderRadius: '0px' }}
                    value={client.adresse}
                    onChange={(e) => setClient({ ...client, adresse: e.target.value })}
                  />
                </div>

                <div className="mb-4">
                  <label className="form-label fw-bold">Téléphone :</label>
                  <input
                    type="text"
                    className="form-control border-dark"
                    style={{ borderRadius: '0px' }}
                    value={client.tel}
                    onChange={(e) => setClient({ ...client, tel: e.target.value })}
                  />
                </div>

                <div className="d-flex justify-content-between">
                  <button
                    type="button"
                    className="btn btn-secondary border-dark"
                    style={{ borderRadius: '0px', width: '48%' }}
                    onClick={() => navigate("/clients")}
                  >
                    <i className="bi bi-arrow-left me-2"></i>Retour à la liste
                  </button>
                  
                  <button
                    type="button"
                    className="btn btn-primary border-dark fw-bold"
                    style={{ borderRadius: '0px', width: '48%' }}
                    onClick={handleUpdate}
                  >
                    <i className="bi bi-check-circle me-2"></i>Mettre à jour
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UpdateClient;