import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

const ClientsList = () => {
  const [clients, setClients] = useState([]);
  
  const fetchData = async () => {
    try {
      const response = await axios.get("http://localhost:3001/clients");
      setClients(response.data);
    } catch (error) {
      console.error("Erreur de chargement:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleDelete = async (id) => {
    if (window.confirm("Voulez-vous vraiment supprimer ce client ?")) {
      try {
        await axios.delete(`http://localhost:3001/clients/${id}`);
        fetchData();
      } catch (error) {
        console.error("Erreur de suppression:", error);
      }
    }
  };

  return (
    <div className="container mt-5">
      <div className="card border-dark" style={{ borderRadius: '0px' }}>
        <div className="card-header bg-dark text-white">
          <div className="d-flex justify-content-between align-items-center">
            <h2 className="mb-0">Liste des Clients</h2>
            <Link to="/clients/create" className="btn btn-success border-dark" style={{ borderRadius: '0px' }}>
              <i className="bi bi-plus-circle me-2"></i>Ajouter un Client
            </Link>
          </div>
        </div>
        
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table table-hover mb-0" style={{ borderRadius: '0px' }}>
              <thead className="table-dark">
                <tr>
                  <th className="border-dark" style={{ borderWidth: '2px', borderRadius: '0px' }}>Nom</th>
                  <th className="border-dark" style={{ borderWidth: '2px', borderRadius: '0px' }}>Adresse</th>
                  <th className="border-dark" style={{ borderWidth: '2px', borderRadius: '0px' }}>Téléphone</th>
                  <th className="border-dark text-center" style={{ borderWidth: '2px', borderRadius: '0px' }}>Opérations</th>
                </tr>
              </thead>
              <tbody>
                {clients.map((client) => (
                  <tr key={client.id} className="border-dark">
                    <td className="border-dark" style={{ borderWidth: '1px' }}>
                      <Link to={`/clients/${client.id}`} className="text-decoration-none fw-bold">
                        {client.nom}
                      </Link>
                    </td>
                    <td className="border-dark" style={{ borderWidth: '1px' }}>{client.adresse}</td>
                    <td className="border-dark" style={{ borderWidth: '1px' }}>{client.tel}</td>
                    <td className="border-dark text-center" style={{ borderWidth: '1px' }}>
                      <div className="btn-group" role="group">
                        <Link 
                          to={`/clients/${client.id}/update`} 
                          className="btn btn-warning border-dark btn-sm me-1" 
                          style={{ borderRadius: '0px' }}
                        >
                          <i className="bi bi-pencil-square me-1"></i>Modifier
                        </Link>
                        <button 
                          onClick={() => handleDelete(client.id)}
                          className="btn btn-danger border-dark btn-sm" 
                          style={{ borderRadius: '0px' }}
                        >
                          <i className="bi bi-trash me-1"></i>Supprimer
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        
        <div className="card-footer bg-light border-dark">
          <div className="text-muted text-center">
            <small>Total: {clients.length} client(s)</small>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClientsList;